#!/usr/bin/env python2
# -*- coding: utf-8 -*-
import json
import codecs
from reedsolo import RSCodec, ReedSolomonError

def decode_received_data():
    rsc = RSCodec(10)  # 10 est le nombre de symboles de correction d'erreur, ajustez en fonction de vos besoins
    received_data = []
    input_path = '/filereceive/encoded_text.txt'
    output_path = '/filereceive/decoded.txt'

    # Lire les données depuis le fichier reçu
    with codecs.open(input_path, 'r', 'utf-8') as file:
        for line in file:
            try:
                # Charger chaque ligne comme un objet JSON
                received_data.append(json.loads(line.strip()))
            except json.JSONDecodeError:
                continue

    # Filtrer les données valides qui contiennent 'data'
    valid_data = [item['data'] for item in received_data if 'data' in item]

    # Vérifier si nous avons des données valides
    if valid_data:
        # Prendre la première occurrence valide
        selected_data = valid_data[0]

        try:
            # Décoder les données avec Reed-Solomon
            decoded_data = rsc.decode(selected_data.encode('latin1'))[0]
            # Écrire la donnée sélectionnée dans le fichier de sortie
            with codecs.open(output_path, 'w', 'utf-8') as file:
                file.write(decoded_data.decode('utf-8') + '\n')
        except ReedSolomonError as e:
            print(f"Erreur Reed-Solomon: {e}")
            # Écrire la donnée non corrigée dans le fichier de sortie
            with codecs.open(output_path, 'w', 'utf-8') as file:
                file.write(selected_data + '\n')

if __name__ == '__main__':
    decode_received_data()

