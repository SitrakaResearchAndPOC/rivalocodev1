import json
import binascii

def calculate_checksum(data):
    return format(binascii.crc32(data) & 0xFFFF, '04x')  # 4 characters long

def decode_json_to_pdf(encoded_path):
    data_chunks = {}
    seen_indices = set()
    total_size = None

    def is_hex_string(s):
        try:
            int(s, 16)
            return True
        except ValueError:
            return False

    # Lire l'index 0 en premier pour obtenir la taille totale
    with open(encoded_path, 'rb') as file:
        for line in file:
            try:
                chunk = json.loads(line.decode('utf-8').strip())
            except json.JSONDecodeError as e:
                print(f"Erreur de décodage JSON: {e}")
                continue

            index = chunk.get('index')
            if index == 0:
                total_size = chunk.get('taille')
                if total_size is None:
                    print(f"Attribut 'taille' manquant pour l'index 0")
                    return ""
                expected_checksum = calculate_checksum(total_size.to_bytes(4, byteorder='big'))
                if chunk.get('checksum') != expected_checksum:
                    print(f"Erreur de checksum pour l'index 0")
                    return ""
                break

    if total_size is None:
        print("L'index 0 n'a pas été trouvé.")
        return ""

    # Lire les autres index
    with open(encoded_path, 'rb') as file:
        for line in file:
            try:
                chunk = json.loads(line.decode('utf-8').strip())
            except json.JSONDecodeError as e:
                print(f"Erreur de décodage JSON: {e}")
                continue

            index = chunk.get('index')
            if index is None or index == 0:
                continue

            if index in data_chunks:
                print(f"Index {index} déjà vu, ignoré.")
                continue

            data_hex = chunk.get('data')
            if data_hex is None:
                print(f"Attribut 'data' manquant pour l'index {index}")
                continue
            if not is_hex_string(data_hex):
                print(f"Erreur : chaîne hexadécimale non valide pour l'index {index}")
                continue
            if len(data_hex) % 2 != 0:
                data_hex = '0' + data_hex  # Assurez-vous que la longueur hex est paire
            data = binascii.unhexlify(data_hex.encode('utf-8'))
            expected_checksum = calculate_checksum(data)
            if chunk.get('checksum') != expected_checksum:
                print(f"Erreur de checksum pour l'index {index}")
                continue

            data_chunks[index] = data
            seen_indices.add(index)

    # Vérifier que tous les index sont présents
    if not seen_indices:
        print("Aucun index valide trouvé.")
        return ""

    expected_total_chunks = max(seen_indices)
    missing_indices = set(range(1, expected_total_chunks + 1)) - seen_indices

    if missing_indices:
        print(f"Index manquants : {sorted(missing_indices)}")
        return ""

    # Assembler les morceaux dans le bon ordre
    decoded_data = b""
    for i in range(1, expected_total_chunks + 1):
        decoded_data += data_chunks[i]

    if len(decoded_data) != total_size:
        print("La taille des données décodées ne correspond pas à la taille attendue")
        return ""

    output_pdf_path = 'decoded_pdf.pdf'
    with open(output_pdf_path, 'wb') as file:
        file.write(decoded_data)

    return output_pdf_path

# Utilisation de la fonction pour décoder un fichier .txt encodé au format JSON
encoded_path = '/filereceive/encoded_pdf.txt'
decoded_pdf_path = decode_json_to_pdf(encoded_path)

if decoded_pdf_path:
    print(f"Le fichier PDF décodé a été écrit dans : {decoded_pdf_path}")
else:
    print("Le décodage du fichier encodé a échoué.")

