import json
import binascii

def calculate_checksum(data):
    return format(binascii.crc32(data.encode('utf-8')) & 0xFFFF, '04x')  # 4 characters long

def decode_json_to_text(encoded_path):
    decoded_text = ""
    index_seen = set()

    with open(encoded_path, 'r', encoding='utf-8') as file:
        valid_chunks = []
        for line_number, line in enumerate(file, start=1):
            line = line.strip()
            if not line:
                continue  # Ignorer les lignes vides

            try:
                chunk = json.loads(line)
            except json.JSONDecodeError as e:
                print(f"Erreur de décodage JSON à la ligne {line_number}: {e}")
                continue

            if not isinstance(chunk, dict):
                print(f"Objet JSON inattendu à la ligne {line_number}: {line[:30]}...")
                continue

            index = chunk.get('index')
            if index is None:
                print(f"Attribut 'index' manquant à la ligne {line_number}")
                continue

            if index in index_seen:
                print(f"Index {index} déjà vu à la ligne {line_number}, ignoré.")
                continue

            if index == 0:
                taille = chunk.get('taille')
                if taille is None:
                    print(f"Attribut 'taille' manquant pour l'index 0 à la ligne {line_number}")
                    continue
                expected_checksum = calculate_checksum(f"0||{taille}")
            else:
                data = chunk.get('data')
                if data is None:
                    print(f"Attribut 'data' manquant pour l'index {index} à la ligne {line_number}")
                    continue
                expected_checksum = calculate_checksum(f"{index}||{data}")

            checksum = chunk.get('checksum')
            if checksum is None:
                print(f"Attribut 'checksum' manquant pour l'index {index} à la ligne {line_number}")
                continue

            if checksum != expected_checksum:
                print(f"Erreur de checksum pour l'index {index} à la ligne {line_number}")
                continue

            valid_chunks.append(chunk)
            index_seen.add(index)

    # Trier les chunks par index et reconstruire le texte
    valid_chunks.sort(key=lambda x: x['index'])
    for chunk in valid_chunks:
        if chunk['index'] != 0:
            decoded_text += chunk['data']

    return decoded_text

# Utilisation de la fonction pour décoder le texte d'un fichier .txt encodé au format JSON
encoded_path = '/filereceive/encoded_text.txt'
decoded_text = decode_json_to_text(encoded_path)

if decoded_text:
    # Écrire le texte décodé dans un nouveau fichier .txt
    decoded_path = 'decoded_text.txt'
    with open(decoded_path, 'w', encoding='utf-8') as file:
        file.write(decoded_text)

    print(f"Le texte décodé est : {decoded_text}")
else:
    print("Le décodage du fichier encodé a échoué.")

