#!/usr/bin/env python2
# -*- coding: utf-8 -*-
import json
import codecs
from reedsolo import RSCodec

def encode_data():
    rsc = RSCodec(10)  # 10 est le nombre de symboles de correction d'erreur
    input_path = '/input/test.txt'
    encoded_path = '/encode/encode_test.txt'

    # Lire les données depuis le fichier d'entrée
    with codecs.open(input_path, 'r', 'utf-8') as file:
        data = file.read()

    # Encoder les données avec Reed-Solomon
    encoded_data = rsc.encode(data.encode('utf-8'))

    # Créer un objet JSON avec les données encodées
    data_with_id = {
        'id': 1,
        'data': encoded_data.decode('latin1')  # Utiliser 'latin1' pour conserver l'encodage binaire
    }

    # Convertir en chaîne JSON
    data_json = json.dumps(data_with_id)

    # Écrire dans le fichier encodé
    with codecs.open(encoded_path, 'w', 'utf-8') as file:
        file.write(data_json)
        file.write('\n')

if __name__ == '__main__':
    encode_data()

