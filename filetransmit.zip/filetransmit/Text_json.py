import json
import binascii

def calculate_checksum(data):
    return format(binascii.crc32(data.encode('utf-8')) & 0xFFFF, '04x')  # 4 characters long

def split_text(text, chunk_size=4):
    return [text[i:i + chunk_size] for i in range(0, len(text), chunk_size)]

def encode_text_to_json(file_path, chunk_size=4):
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()
    
    chunks_metadata = []
    
    # Index 0: Informations sur la taille du texte
    total_size = len(text)
    checksum_size = calculate_checksum(f"0||{total_size}")
    chunks_metadata.append({
        'index': 0,
        'taille': total_size,
        'checksum': checksum_size
    })

    # Index 1 et suivants: Données du texte
    chunks = split_text(text, chunk_size)
    for index, chunk in enumerate(chunks, start=1):
        checksum = calculate_checksum(f"{index}||{chunk}")
        chunks_metadata.append({
            'index': index,
            'data': chunk,
            'checksum': checksum
        })

    # Convertir en chaînes JSON
    metadata_json_lines = [json.dumps(chunk) for chunk in chunks_metadata]
    
    # Écrire dans un fichier .txt
    encoded_path = '/encode/encoded_text.txt'
    with open(encoded_path, 'w', encoding='utf-8') as file:
        file.write('\n'.join(metadata_json_lines))
    
    return encoded_path

# Utilisation de la fonction pour encoder le texte d'un fichier .txt
text_file_path = '/input/test.txt'
encoded_path = encode_text_to_json(text_file_path, chunk_size=4)
print(f"Le texte encodé a été écrit dans : {encoded_path}")

