import json
import binascii

def calculate_checksum(data):
    return format(binascii.crc32(data) & 0xFFFF, '04x')  # 4 characters long

def split_binary(data, chunk_size=1024):
    return [data[i:i + chunk_size] for i in range(0, len(data), chunk_size)]

def encode_pdf_to_json(file_path, chunk_size=1024):
    with open(file_path, 'rb') as file:
        pdf_data = file.read()
    
    chunks_metadata = []
    
    # Index 0: Informations sur la taille du texte encodé
    total_size = len(pdf_data)
    checksum_size = calculate_checksum(total_size.to_bytes(4, byteorder='big'))
    chunks_metadata.append({
        'index': 0,
        'taille': total_size,
        'checksum': checksum_size
    })

    # Index 1 et suivants: Données binaires
    chunks = split_binary(pdf_data, chunk_size)
    for index, chunk in enumerate(chunks, start=1):
        checksum = calculate_checksum(chunk)
        hex_data = binascii.hexlify(chunk).decode('utf-8')
        chunks_metadata.append({
            'index': index,
            'data': hex_data,
            'checksum': checksum
        })

    # Écrire chaque objet JSON dans une ligne du fichier .txt en mode binaire
    encoded_path = 'encoded_pdf.txt'
    with open(encoded_path, 'wb') as file:
        for chunk_metadata in chunks_metadata:
            line = json.dumps(chunk_metadata) + '\n'
            file.write(line.encode('utf-8'))
    
    return encoded_path

# Utilisation de la fonction pour encoder un fichier PDF
pdf_file_path = '/filetransmit/mémoire.pdf'
encoded_path = encode_pdf_to_json(pdf_file_path, chunk_size=1024)
print(f"Le fichier PDF encodé a été écrit dans : {encoded_path}")

