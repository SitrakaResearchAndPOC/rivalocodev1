#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import json

# Chemins des fichiers
input_path = '/input/test.txt'
output_path = '/encode/encode_test.txt'

# Vérifier que les répertoires existent, sinon les créer
#os.makedirs(os.path.dirname(input_path), exist_ok=True)
#os.makedirs(os.path.dirname(output_path), exist_ok=True)

# Lire les données depuis le fichier
with open(input_path, 'r', encoding='utf-8') as file:
    data = file.read()

# Ajouter un identifiant unique
data_with_id = {
   'id': 1,  # Par exemple, un numéro de séquence
   'data': data
}

# Structurer les données en JSON
data_json = json.dumps(data_with_id, ensure_ascii=False)

# Écrire les données JSON dans le fichier source de GNU Radio
with open(output_path, 'w', encoding='utf-8') as file:
    file.write(data_json)

