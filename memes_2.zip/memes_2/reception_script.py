#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json

def main():
    # Chemin du fichier de réception
    input_file = '/filereceive/encoded.txt'

    # Liste pour stocker les messages corrects
    correct_messages = []

    # Lire les données depuis le fichier reçu
    with open(input_file, 'r', encoding='utf-8') as file:
        for line in file:
            try:
                data = json.loads(line.strip())
                # Vérifier si le message est correct
                if 'message' in data and isinstance(data['message'], str):
                    correct_messages.append(data['message'])
                    # Arrêter dès qu'on a trouvé un ou deux messages corrects
                    if len(correct_messages) >= 2:
                        break
            except json.JSONDecodeError:
                continue

    # Imprimer les messages corrects
    for message in correct_messages:
        print(message)

if __name__ == '__main__':
    main()

